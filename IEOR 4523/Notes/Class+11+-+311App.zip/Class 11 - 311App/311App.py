import os
import sys
from flask import Flask, request, session, g, redirect, url_for, abort, render_template

from flaskext.mysql import MySQL
from flask_wtf import FlaskForm
from wtforms.fields.html5 import DateField
from wtforms import SelectField
from datetime import date
import time
import gmplot
import pandas

app = Flask(__name__)

app.secret_key = 'A0Zr98s984jnflskj_sdkfjhT'

mysql = MySQL()

app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''
app.config['MYSQL_DATABASE_DB'] = 'flask'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)

conn = mysql.connect()
cursor = conn.cursor()

class MapParamsForm(FlaskForm):
  dtfrom = DateField('DatePicker', format='%Y-%m-%d', default=date(2016,1,1))
  dtto = DateField('DatePicker', format='%Y-%m-%d', default=date(2016,1,2))

class AnalyticsForm(FlaskForm):
	attributes = SelectField('Data Attributes', choices=[('Agency', 'Agency'), ('Borough', 'Borough'), ('Complaint Type', 'Complaint Type')])

def get_homepage_links():
	return 	[	
						{"href": url_for('analytics'), "label":"Analytics"},
						{"href": url_for('analytics'), "label":"Analysefwertics"},
					]

def get_data(dtfrom, dtto):
	query = "select latitude, longitude from incidents where created_date >= '" + dtfrom + "' and created_date <= '" + dtto + "';"
	cursor.execute(query)
	return cursor.fetchall()

def get_df_data():
	query = "select unique_key, agency, complaint_type, borough from incidents;"
	cursor.execute(query)
	data = cursor.fetchall()
	df = pandas.DataFrame(data=list(data),columns=['Unique_key','Agency','Complaint Type','Borough'])
	return df

'''
@app.route("/")
def home():
   return 'Welcome to the 311 Analysis App!'

if __name__ == '__main__':
   app.run(debug = True)
'''
@app.route("/")
def home():
	#session["data_loaded"] = True
	return render_template('home.html', links=get_homepage_links())

@app.route('/analytics/',methods=['GET','POST'])
def analytics():
	form = AnalyticsForm()
	if form.validate_on_submit():
		df = get_df_data()
		column = request.form.get('attributes')
		group = df.groupby(column)
		ax = group.size().plot(kind='bar')
		fig = ax.get_figure()
		filename = 'static/charts/group_by_figure.png_'+str(int(time.time()))+".png"
		fig.savefig(filename)
		return render_template('analytics.html', chart_src="/"+filename)

	return render_template('analyticsparams.html', form=form)

if __name__ == "__main__":
    app.run() #debug = True)

